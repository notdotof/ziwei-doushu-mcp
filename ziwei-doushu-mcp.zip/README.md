# ziwei-doushu MCP · 紫微斗数排盘服务（单文件版）

倪海厦《天纪》三合派紫微斗数 MCP 服务，**已打包成单个 JS 文件**：无需 npm install、无需克隆源码，装好 Node.js 即可使用。

## 包含工具

| 工具 | 功能 |
|---|---|
| `ziwei_paipan` | 按公历出生时间排命盘：十二宫星曜、四化、大限。自动真太阳时校正（含均时差），支持全国城市经度表与海外时区。 |
| `ziwei_interpret` | 排盘并返回完整解读资料包（固化解读规范＋命盘＋命中格局＋《天纪》原话＋古籍原文＋名人对照），由当前对话模型直接据此作答。 |
| `ziwei_dataset` | 从开源解读数据集 v4.0（67.5 万命盘 × 13 维，解压后 56.6 GB）按出生信息**精确取对应命盘的解读长文**：命格总览/性格/感情/事业/财运/健康/兄弟/子女/迁移/人际/田宅/福德/父母，每维约两千余字。**可选增强**：不装数据集时其余三个工具照常可用。 |
| `ziwei_knowledge` | 按关键词检索本地资料库：《天纪·紫微斗数》倪师原话（1848 条，含时间码与出处链接）＋三部古籍（骨髓赋／紫微斗数全集／紫微斗数全书）。 |

> 本服务**不调用任何模型、不联网**，全部计算与检索都在本地完成。

## 环境要求

- **Node.js ≥ 18**（仅此一项）。检查：终端运行 `node -v`。
  未安装可到 https://nodejs.org 下载 LTS 版。

## 目录结构（请保持，勿拆散）

```
ziwei-doushu-mcp/
├─ server/
│  └─ ziwei-server.mjs      ← 服务入口（打包好的单文件）
└─ docs/
   └─ tianji-ziwei/
      └─ entries.jsonl      ← 《天纪》语料（服务按相对路径读取）
```

解压后放到一个固定位置即可，例如 Windows 下 `D:\mcp\ziwei-doushu-mcp\`。

## MCP 客户端配置

`command` 填 node（或 node.exe 的绝对路径），`args` 填 `ziwei-server.mjs` 的**绝对路径**。

**Qoder**：设置 → MCP → 添加自定义 MCP（JSON），粘入：

```json
{
  "mcpServers": {
    "ziwei-doushu": {
      "command": "node",
      "args": ["D:\\mcp\\ziwei-doushu-mcp\\server\\ziwei-server.mjs"]
    }
  }
}
```

**Claude Desktop / 其他标准 MCP 客户端**：格式相同，写入对应配置文件（Claude Desktop 为 `claude_desktop_config.json`）。macOS / Linux 把路径换成正斜杠，如 `/Users/xxx/mcp/ziwei-doushu-mcp/server/ziwei-server.mjs`。

保存后在客户端里重载 / 重连该 MCP，出现 3 个 `ziwei_` 开头的工具即成功。

## 使用示例

对 AI 直接说：

- 「帮我排盘：男，1998 年 12 月 2 日 14 时 25 分，广东梅州」
- 「解读一下这个命盘的感情和事业」（会走 `ziwei_interpret` 资料包）
- 「查一下《天纪》里关于化忌的原话」（走 `ziwei_knowledge`）

出生信息给得越全越好：公历年月日＋钟表时间（几时几分）＋性别＋出生省市；海外出生可另给时区偏移。

## 数据集（可选增强）：ziwei_dataset

`ziwei_dataset` 依赖上游作者发布的**解读数据集 v4.0**（674,976 张命盘 × 13 维 = 877 万段解读）。它不随本包分发，按需安装：

**一条命令安装**（PowerShell，默认装 1975–2005 共 31 年，约 23 GB 磁盘；自动下载 zstd 解压器）：

```powershell
powershell -ExecutionPolicy Bypass -File get-dataset.ps1                 # 默认 1975-2005
powershell -ExecutionPolicy Bypass -File get-dataset.ps1 -From 1990 -To 1999   # 自定年份
```

**或手动**：到上游 Release [v4.0-13d](https://github.com/Renhuai123/ziwei-doushu/releases/tag/v4.0-13d) 下载 `year-<年份>.jsonl.zst`（全量压缩仅 161 MB），用 zstd 解压（`--long=27` 参数必须带），把得到的 `year-<年份>.jsonl` 放进包根的 `data\interp-v4\` 目录。**无需重启**，服务按需读取并自动建索引。

- 也可以用环境变量 `ZIWEI_DATASET_DIR` 把数据集放到任意位置。
- 未装数据集时调用 `ziwei_dataset` 会返回安装指引，不影响其它工具。

## 口径说明

- 排盘统一走 `lib/ziwei/true-solar-time.ts` 引擎：真太阳时＝钟表时间＋经度修正＋均时差（NOAA 近似）；晚子时按次日排盘。
- 生年四化按农历年干取；单位分类以站点 mark 标注为准。
- 解读遵循倪海厦《天纪·紫微斗数》三合派：命宫为本、三方四正为用。
- 命理内容为传统参考，不构成任何现实决策依据。
